import java.io.*;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class MvtDistributorMain {

    private static final String PROPERTIES_PATH = "config/config.properties";
    private static String DISTRIBUTE_PATH = "";
    private static String TARGET_EXTENSION = "";
    private static String DIRECTORY_SEPARATOR = "";

    public static void main(String[] args) throws Exception {

        FileReader resource = new FileReader(PROPERTIES_PATH);
        Properties properties = new Properties();

        try{
            properties.load(resource);
            DISTRIBUTE_PATH = properties.getProperty("path");
            TARGET_EXTENSION = properties.getProperty("extension");
            DIRECTORY_SEPARATOR = properties.getProperty("separator");
        } catch (IOException e) {
            e.printStackTrace();
        }

        List<String> filePathList = getFilePath(DISTRIBUTE_PATH, TARGET_EXTENSION);

        System.out.println("DISTRIBUTE PATH: " + DISTRIBUTE_PATH);
        System.out.println("EXTENSION: " + TARGET_EXTENSION);
        System.out.println("SEPARATOR: " + DIRECTORY_SEPARATOR);

        for (String filePath : filePathList) {
            directoryStructure(DISTRIBUTE_PATH, filePath, DIRECTORY_SEPARATOR, TARGET_EXTENSION);
        }

    }

    public static void directoryStructure(String _distributePath, String _filePath, String _directorySeparator, String _targetExtension) {

        String fileName = _filePath.replaceAll(_distributePath + File.separator, "").replaceAll("." + _targetExtension, "");

        String depth_1 = fileName.split(_directorySeparator)[0];
        String depth_2 = fileName.split(_directorySeparator)[1];
        String depth_3 = fileName.split(_directorySeparator)[2];

        System.out.println("depth_1: " + fileName.split(_directorySeparator)[0]);
        System.out.println("depth_2: " + fileName.split(_directorySeparator)[1]);
        System.out.println("fileName: " + fileName.split(_directorySeparator)[2]);

        List<String> makeFolderNames = new ArrayList<>();
        makeFolderNames.add(_distributePath + File.separator + depth_1); // ~/{z}
        makeFolderNames.add(_distributePath + File.separator + depth_1 + File.separator + depth_2); // ~/{z}/{x}

        for (String _folderPath : makeFolderNames) {
            mkdir(_folderPath);
        }

        String origin = _filePath;
        String dest =  _distributePath + File.separator + depth_1 + File.separator + depth_2 + File.separator + depth_3 + "." + _targetExtension;

        moveTo(origin, dest);
    }

    public static void mkdir(String _path) {
        File dir = new File(_path);

        // 해당 디렉토리가 없을경우 디렉토리를 생성합니다.
        if (!dir.exists()) {
            try{
                dir.mkdir(); //폴더 생성합니다.
                System.out.println("[make directory] " + _path);
            } catch(Exception e ){
                e.getStackTrace();
            }
        }else {
            System.out.println("[exist directory] " + _path);
        }
    }

    public static void moveTo(String _origin, String _destination) {
        Path srcPath = Paths.get(_origin);
        Path dstPath = Paths.get(_destination);

        System.out.println("origin: " + _origin);
        System.out.println("desti: " + _destination);

        try {
            Files.move(srcPath, dstPath, StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
           e.printStackTrace();
        }
    }

    public static List<String> getFilePath(String _targetPath, String _extension) {
        List<String> filePathList = new ArrayList<>();

        File dir = new File(_targetPath);
        FilenameFilter filter = new FilenameFilter() {
            public boolean accept(File f, String name) {
                return name.endsWith(_extension);
            }
        };

        File files[] = dir.listFiles(filter);
        for (int i = 0; i < files.length; i++) {
            filePathList.add(files[i].getPath());
        }

        return filePathList;
    }

}
